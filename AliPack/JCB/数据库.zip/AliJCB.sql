-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: apkjcb
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apktool`
--

DROP TABLE IF EXISTS `apktool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apktool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apktool`
--

LOCK TABLES `apktool` WRITE;
/*!40000 ALTER TABLE `apktool` DISABLE KEYS */;
INSERT INTO `apktool` VALUES (1,'apktool2.8.1','apktool_2.8.1.jar'),(2,'apktool2.7.1','apktool_2.7.1.jar'),(3,'apktool2.6.1','apktool_2.6.1.jar'),(4,'apktool2.9.0','apktool_2.9.0.jar');
/*!40000 ALTER TABLE `apktool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app`
--

DROP TABLE IF EXISTS `app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `type` enum('APK','IOS','MIXED') NOT NULL,
  `down_url` json DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `task_status` enum('PACKING','FINISH','NOTSTARTED','UNPACKING','GENERATELINK','FAIL') DEFAULT 'NOTSTARTED',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1自动打包 0手动打包',
  `due_time` datetime DEFAULT NULL,
  `create_nums` int(11) NOT NULL DEFAULT '0' COMMENT '生成次数',
  `last_create_time` datetime DEFAULT NULL,
  `custom_apk_name` varchar(255) DEFAULT NULL COMMENT '自定义apk名',
  `custom_name` varchar(255) DEFAULT NULL COMMENT '自定义包名',
  `path` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `jiagu` tinyint(4) DEFAULT '0',
  `apktool` int(11) DEFAULT NULL,
  `replace` tinyint(4) DEFAULT '0',
  `auto_pack_name` tinyint(4) DEFAULT '1',
  `random_apk_name` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `domain_crt` varchar(255) DEFAULT NULL,
  `key_crt` varchar(255) DEFAULT NULL,
  `root_crt` varchar(255) DEFAULT NULL,
  `replace_pic` tinyint(4) DEFAULT '1',
  `current_pack_name` varchar(255) DEFAULT NULL,
  `old_pack_name` varchar(255) DEFAULT NULL,
  `custom_key_id` bigint(20) DEFAULT NULL,
  `custom_key_store` tinyint(4) DEFAULT '0',
  `download_num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `path` (`path`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app`
--

LOCK TABLES `app` WRITE;
/*!40000 ALTER TABLE `app` DISABLE KEYS */;
INSERT INTO `app` VALUES (1,'APK打包','APK','[{\"url\": \"#\", \"name\": \"localDownUrl\"}, {\"url\": \"\", \"name\": \"aliyunDownUrl\"}, {\"url\": \"\", \"name\": \"qiniuDownUrl\"}, {\"url\": \"\", \"name\": \"huaweiDownUrl\"}, {\"url\": \"https://ktzali-1300939157.cos.ap-hongkong.myqcloud.com/jcb/测试.apk\", \"name\": \"tencentDownUrl\"}, {\"url\": \"\", \"name\": \"awsDownUrl\"}, {\"url\": \"\", \"name\": \"ftpDownUrl\"}, {\"url\": \"\", \"name\": \"azureDownUrl\"}, {\"url\": \"\", \"name\": \"baiduDownUrl\"}, {\"url\": \"\", \"name\": \"ksDownUrl\"}]','2025-04-30 07:48:58',1,0,NULL,'FINISH',0,NULL,1,'2025-04-30 07:49:08','测试',NULL,'storage/1/apk/8459c317a1d1454f9fa59ef79c818e9c.apk','处理APK',0,4,0,1,'93b723c09c164126ae4cb115b61d5279',NULL,NULL,NULL,NULL,0,'com.mycompany.qxgkwne','com.mycompany.myapp3',NULL,0,0),(2,'网站打包','MIXED','[{\"url\": \"#\", \"name\": \"localDownUrl\"}, {\"url\": \"\", \"name\": \"aliyunDownUrl\"}, {\"url\": \"\", \"name\": \"qiniuDownUrl\"}, {\"url\": \"\", \"name\": \"huaweiDownUrl\"}, {\"url\": \"https://ktzali-1300939157.cos.ap-hongkong.myqcloud.com/jcb/网站打包.apk\", \"name\": \"tencentDownUrl\"}, {\"url\": \"\", \"name\": \"awsDownUrl\"}, {\"url\": \"\", \"name\": \"ftpDownUrl\"}, {\"url\": \"\", \"name\": \"azureDownUrl\"}, {\"url\": \"\", \"name\": \"baiduDownUrl\"}, {\"url\": \"\", \"name\": \"ksDownUrl\"}]','2025-04-30 07:50:04',1,0,'http://154.12.16.18:9025/15eaede5a87a45cf8a87eda4d08f8bef.png','FINISH',0,NULL,2,'2025-04-30 08:12:35','网站打包',NULL,'storage/1/mixed/logo/15eaede5a87a45cf8a87eda4d08f8bef.png','网站打包APK',0,NULL,0,1,'796e8050a341485ca124ccce8d497270','http://www.ktzali.cn',NULL,NULL,NULL,0,'com.fdni.fkyb','com.bobo.test',NULL,0,0),(3,'网站iOS封装','IOS','[{\"url\": \"\", \"name\": \"localDownUrl\"}, {\"url\": \"\", \"name\": \"aliyunDownUrl\"}, {\"url\": \"\", \"name\": \"qiniuDownUrl\"}, {\"url\": \"\", \"name\": \"huaweiDownUrl\"}, {\"url\": \"\", \"name\": \"tencentDownUrl\"}, {\"url\": \"\", \"name\": \"awsDownUrl\"}, {\"url\": \"\", \"name\": \"ftpDownUrl\"}, {\"url\": \"\", \"name\": \"azureDownUrl\"}, {\"url\": \"\", \"name\": \"baiduDownUrl\"}, {\"url\": \"\", \"name\": \"ksDownUrl\"}]','2025-04-30 08:00:25',1,1,'http://154.12.16.18:9025/13f12d91b91c483ba34b80c97a82a657.png','FINISH',0,NULL,6,'2025-04-30 08:33:37',NULL,NULL,'storage/1/ios/logo/13f12d91b91c483ba34b80c97a82a657.png','IOS封装',0,NULL,0,1,NULL,'http://www.ktzali.cn','storage/1/ios/domain/93eafad50b43459abfb38f5b66805af7.crt','storage/1/ios/key/c1be9c24e0d641ff8a3fb9312a211b31.key','storage/1/ios/root/e9fa53318ccc41feb1b3ee8f9a32df9a.crt',1,NULL,NULL,NULL,0,0);
/*!40000 ALTER TABLE `app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `store_pass` varchar(255) NOT NULL,
  `key_pass` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `usable` tinyint(4) NOT NULL DEFAULT '1',
  `del` tinyint(4) NOT NULL DEFAULT '0',
  `user_id` bigint(20) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1jks 2keystore',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate`
--

LOCK TABLES `certificate` WRITE;
/*!40000 ALTER TABLE `certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `del` int(11) DEFAULT '0',
  `task_num` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES (1,'admin','123456',0,1,1,'2023-11-28 08:34:10','2023-11-28 08:34:10');
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oss`
--

DROP TABLE IF EXISTS `oss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) DEFAULT NULL,
  `prefix` varchar(255) DEFAULT NULL,
  `end_point` varchar(255) DEFAULT NULL,
  `access_key_id` varchar(255) DEFAULT NULL,
  `access_key_secret` varchar(255) DEFAULT NULL,
  `bucket_name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` enum('aliyun','huawei','ftp','aws','qiniu','tencent','azure','baidu','ks') DEFAULT NULL,
  `app_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oss`
--

LOCK TABLES `oss` WRITE;
/*!40000 ALTER TABLE `oss` DISABLE KEYS */;
INSERT INTO `oss` VALUES (1,'https://hoo-yyyy.oss-cn-beijing.aliyuncs.com','','oss-cn-=','test','qwe123','dfasfdsa','bjbjl','',1,1,'aliyun',NULL),(2,'http://image.boliao.top','','','test','test','kapok-shop','test','',0,1,'qiniu',NULL),(3,'','','asdfsadfa','asdfsadf','dsafsaf','fasgeg','','',0,1,'huawei',NULL),(4,'127.0.0.1','','21','test','123456','','','',0,1,'ftp',NULL),(5,'1','','us-east-1','AKIATAVAAVWG4GUJDHRG','lpQSGzuSw15QsZO1EFRFfuOZynKap/Rr1PX2Eg9e','stp-yz3ws','','',1,1,'aws',NULL),(6,'http://adfaf.vcom','','ap-hongkong','AKIDNctxpUv87tRmtoVyFI7tSnwsb6NQFqEO','0nOl37yf8OQEoBLHzTlqgW8Wt43oLlyy','ktzali-1300939157','jcb','',1,1,'tencent','1300939157'),(10,'asdf',NULL,NULL,'asdf','asdf','asdf','asdf',NULL,1,8,'qiniu',NULL),(11,'hootest',NULL,NULL,'dsdfsadfas',NULL,'hellow',NULL,NULL,1,1,'azure',NULL),(12,NULL,NULL,'gz.bcebos.com','23123123','qw1wesewwqwe','12e21e12sd','test',NULL,1,1,'baidu',NULL);
/*!40000 ALTER TABLE `oss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replace_xml`
--

DROP TABLE IF EXISTS `replace_xml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replace_xml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `words` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replace_xml`
--

LOCK TABLES `replace_xml` WRITE;
/*!40000 ALTER TABLE `replace_xml` DISABLE KEYS */;
INSERT INTO `replace_xml` VALUES (1,'解决华为/vivo/oppo报毒规则1','ACCESS_FINE_LOCATION','INTERNET',1,1),(2,'解决华为/vivo/oppo报毒规则2','MANAGE_EXTERNAL_STORAGE','INTERNET',1,1),(3,'解决华为/vivo/oppo报毒规则3','READ_CALL_LOG','INTERNET',1,1),(4,'解决华为/vivo/oppo报毒规则4','READ_CONTACTS','INTERNET',1,1),(5,'解决华为/vivo/oppo报毒规则5','READ_PHONE_STATE','INTERNET',1,1),(6,'解决华为/vivo/oppo报毒规则6','READ_SMS','INTERNET',1,1),(7,'解决华为/vivo/oppo报毒规则7','RECORD_AUDIO','INTERNET',1,1),(8,'解决华为/vivo/oppo报毒规则8','WRITE_EXTERNAL_STORAGE','INTERNET',1,1),(9,'解决华为/vivo/oppo报毒规则9','ACCESS_COARSE_LOCATION','INTERNET',1,1),(10,'解决华为/vivo/oppo报毒规则10','READ_EXTERNAL_STORAGE','INTERNET',1,1),(11,'解决华为/vivo/oppo报毒规则11','CAMERA','INTERNET',1,1),(12,'规则12','GET_TASKS','INTERNET',1,1),(13,'规则13','MOUNT_UNMOUNT_FR_ESYSTEMS','INTERNET',1,1),(14,'规则14','REQUEST_INSTALL_PACKAOES','INTERNET',1,1),(15,'规则15','SYSTEM_ALERT_WINDOW','INTERNET',1,1),(16,'规则16','OET_ACCOUNTS','INTERNET',1,1),(17,'规则17','REAT_LOGS','INTERNET',1,1);
/*!40000 ALTER TABLE `replace_xml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system`
--

DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cron` varchar(128) NOT NULL,
  `start_time` varchar(128) NOT NULL,
  `end_time` varchar(128) NOT NULL,
  `min_name` varchar(128) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `way` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system`
--

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES (1,'0 0/5 * * * ?','18:00','14:59','5分钟',1,0);
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apkjcb'
--

--
-- Dumping routines for database 'apkjcb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-30 17:25:59
